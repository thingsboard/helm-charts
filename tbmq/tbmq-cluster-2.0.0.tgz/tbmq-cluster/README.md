# Helm Chart for TBMQ Cluster

TBMQ is a high-performance MQTT message broker capable of handling 4M+ concurrent client connections,
delivering 3M+ messages per second per single cluster node with low latency. In cluster mode,
TBMQ scales to 100M+ concurrently connected clients.

This chart deploys a TBMQ cluster on Kubernetes. The same chart supports both editions of TBMQ:

- **Community Edition (CE)** — open-source, default images.
- **Professional Edition (PE)** — commercial edition with additional features. Enabled by switching
  the broker and integration-executor images to the PE variants in your `values.yaml` and supplying
  a license. All templates, configuration keys, and operational behavior are identical between
  editions. See [Professional Edition (PE)](#professional-edition-pe) under "Installing" for the
  exact edits.

**Documentation & Resources:**

- TBMQ [Documentation](https://thingsboard.io/products/mqtt-broker/)
- TBMQ GitHub [Repository](https://github.com/thingsboard/tbmq)
- ThingsBoard Charts GitHub [Repository](https://github.com/thingsboard/helm-charts)

> **Trademarks:** This software listing is packaged by the TBMQ Team. The respective trademarks
> mentioned in the offering are owned by the respective companies, and use of them does not imply
> any affiliation or endorsement.

## Architecture

The chart deploys only TBMQ application components:

- `tbmq-node` — broker StatefulSet (default 2 replicas). Exposes MQTT (1883), MQTTS (8883), MQTT-WS
  (8084), MQTT-WSS (8085), and an HTTP management API (8083).
- `tbmq-ie` — Integration Executor StatefulSet (default 2 replicas). Exposes HTTP (8082).
- Helm hooks for one-shot install Pod and upgrade Job that run TBMQ's database schema initializer
  or migration tool.
- Optional `Ingress` and `Service` resources for HTTP and MQTT load balancing
  (`nginx`, `aws`, `azure`, or `gcp` flavors).

Infrastructure dependencies — PostgreSQL, Kafka, and a Redis-compatible cache — must be deployed
separately. Use whatever fits your environment: operators (CrunchyData PGO, Strimzi, Valkey
Operator), managed services (RDS, MSK, ElastiCache), or raw manifests. The chart connects to your
existing instances via the values you provide.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.8.0+
- Persistent Volume provisioner — required by default for the broker's per-pod `/data` PVC
  (`tbmq.persistence.enabled: true`) and by whatever infrastructure components you run that use
  PVs. CE-only deployments can disable broker persistence (`tbmq.persistence.enabled: false`) if
  no PV provisioner is available — see [Persistence](#persistence) for the trade-offs and why PE
  should keep it on.
- An external PostgreSQL instance (with an empty database created for TBMQ)
- An external Kafka cluster
- An external Redis-compatible cache (Redis, Valkey, Dragonfly, etc.) — standalone or cluster

For a working step-by-step example using Minikube with CrunchyData PGO, Strimzi Kafka, and Valkey,
see the [Minikube Deployment Guide](docs/minikube/README.md).

## Installing

### Step 1: Add the TBMQ Helm Repository

```bash
helm repo add tbmq-helm-chart https://helm.thingsboard.io/tbmq
helm repo update
```

### Step 2: Prepare Your `values.yaml`

Export the chart defaults as a starting point, then edit it to match your environment:

```bash
helm show values tbmq-helm-chart/tbmq-cluster > values.yaml
```

At a minimum you need to set:

- `postgresql.host` and credentials (or `existingSecret`)
- `kafka.bootstrapServers`
- `redis.nodes` (cluster mode is the default) — or `redis.connectionType: standalone` plus `redis.host`/`redis.port` — and credentials if `usePassword: true`

See [Infrastructure Configuration](#infrastructure-configuration) for full parameter reference.

> **Important:** Do not set `installation.installDbSchema: true` in `values.yaml`. Pass it via
> `--set` on the `helm install` command instead. Persisting it in your values file means the install
> pod will also run on every subsequent `helm upgrade` (because the post-install hook is also bound
> to `post-upgrade` to allow recovery from a forgotten flag).

### Step 3: Install

#### Community Edition (CE)

```bash
helm install my-tbmq tbmq-helm-chart/tbmq-cluster \
  -f values.yaml \
  --set installation.installDbSchema=true
```

#### Professional Edition (PE)

PE installs from the same chart as CE. You configure PE by making two edits to the `values.yaml` you exported in Step 2:

1. Switch the broker and integration-executor images to the PE variants
   (`thingsboard/tbmq-pe-node` and `thingsboard/tbmq-pe-integration-executor`).
2. Provide a license.

Both edits are detailed below. After making them, run the `helm install` command as for CE.

> The repo ships [`values-pe.yaml`](values-pe.yaml) as a **reference** for the canonical PE image
> repositories and tags at the current chart version. Copy those values into your `values.yaml`
> in Step 1; do not pass `values-pe.yaml` itself as a `-f` overlay alongside your file.

##### 1. Switch to PE images

Find the `tbmq.image` and `tbmq-ie.image` blocks in your `values.yaml` and change `repository`
and `tag` to the PE values:

```yaml
tbmq:
  image:
    repository: thingsboard/tbmq-pe-node                  # was: thingsboard/tbmq-node
    tag: 2.3.0PE                                          # was: 2.3.0

tbmq-ie:
  image:
    repository: thingsboard/tbmq-pe-integration-executor  # was: thingsboard/tbmq-integration-executor
    tag: 2.3.0PE                                          # was: 2.3.0
```

PE tags match the chart `appVersion` with a `PE` suffix (e.g. `2.3.0` → `2.3.0PE`). The CE and PE
image tags are **not** interchangeable. The canonical reference values for the current chart
version are in [`values-pe.yaml`](values-pe.yaml).

##### 2. Provide your license

**Recommended (production):** keep the license out of `values.yaml` by pre-creating a Kubernetes
Secret and referencing it from values:

```bash
kubectl create namespace <namespace>
kubectl create secret generic my-tbmq-license -n <namespace> \
  --from-literal=license-key='YOUR_LICENSE_VALUE'
```

```yaml
license:
  existingSecret: my-tbmq-license
  # The chart reads the license from a key named "license-key" inside the Secret.
  # If your Secret uses a different key, set existingSecretLicenseKey: <your-key>.
```

Why this is the recommended path:

- The license value never lives in `values.yaml` on disk, so the file is safe to keep in version
  control alongside the rest of your infra config.
- Composes with sealed-secrets, External Secrets Operator, SOPS, Vault, or any other tool that
  produces a Kubernetes Secret in the release's namespace — point `existingSecret` at the name
  it produces and the chart picks it up unchanged.
- Rotating the license is `kubectl edit secret` — no `helm upgrade` round-trip.
- The Secret survives `helm uninstall`, so reinstalling the release does not require re-pasting
  the license value.

**Alternative (test / dev):** paste the license value into your `values.yaml` and the chart will
render the Secret for you (`<release>-tbmq-license-secret`):

```yaml
license:
  secret: YOUR_LICENSE_VALUE
```

This is fine for quick experiments, but the value lands inside the helm release manifest stored
in the cluster (`sh.helm.release.v1.<name>.<rev>` Secret), and anyone with `get secrets`
permission in that namespace can read it back.

##### 3. Install

Because every PE-specific change is in your `values.yaml`, the install command is identical to
the CE one:

```bash
helm install my-tbmq tbmq-helm-chart/tbmq-cluster \
  -f values.yaml \
  --set installation.installDbSchema=true
```

> **Tip:** `my-tbmq` is the **Helm release name**. Pick any name. It is used as the prefix for
> all deployed resources and as the reference for future `helm` commands against this release.

##### How the chart wires the license

Only the broker StatefulSet validates the license, so the chart injects two license env vars
**only** there. The IE StatefulSet, the install Pod, and the pre-upgrade Job do not consume the
license Secret and do not depend on it.

- `TBMQ_LICENSE_SECRET` — read from the Secret you provided (inline or via `existingSecret`).
- `TBMQ_LICENSE_INSTANCE_DATA_FILE` — path to the per-pod local cache of the license client's
  activation response. The default (`/data/tbmq-instance-license-$(TB_SERVICE_ID).data`) lives on
  `/data`, backed by a per-pod PVC when `tbmq.persistence.enabled=true` (the default — see
  [Persistence](#persistence) below). `$(TB_SERVICE_ID)` is the pod name (downward API), so each
  replica gets its own cache file. Persisting `/data` lets the broker check in against its
  existing license instance on restart; **without the cache file, the broker re-activates as a
  fresh instance on every start, consuming a new slot against the license's instance cap** (see
  [Persistence](#persistence) for the full explanation). Override `license.instanceDataFile` only
  if you mount a different writable path.

> The TBMQ cluster id that the license server binds to lives in PostgreSQL
> (`tbmq_cluster.cluster_id`, generated once at install). It is not stored in `/data` and is
> unaffected by Pod recreation.

### Step 4: Verify the Install

```bash
# List the broker, integration executor, and install-pod resources
kubectl get pods -n <namespace> -l 'app in (my-tbmq-tbmq-node,my-tbmq-tbmq-ie,install-job)'
```

(The chart sets only the bare `app:` label — there is no `app.kubernetes.io/instance` selector to filter by release name.)

The install pod (`my-tbmq-install-pod`) runs to completion (its `restartPolicy` is `OnFailure`,
so a failed container restarts in-pod until it succeeds or the hook timeout fires), creates the
schema, then exits. The hook policy is `hook-succeeded,before-hook-creation`: Helm deletes the
pod **only when it succeeds**; on failure the pod is **left in place** so you can inspect logs,
and it is auto-cleaned the next time the hook runs (e.g., the next `helm upgrade`). The install
hook has a 300s timeout.

The `my-tbmq-tbmq-node-*` (broker) pods block in their `validate-db` init container until the
schema exists, so they reach `Running` within a minute or two **after** the install pod succeeds.
The `my-tbmq-tbmq-ie-*` pods have no PostgreSQL dependency and may already be `Running` before
the install pod completes.

```bash
# While the pod runs:
kubectl logs my-tbmq-install-pod -n <namespace> -f

# If it has already finished and was restarted (restartPolicy: OnFailure):
kubectl logs my-tbmq-install-pod -n <namespace> --previous
```

## Updating Configuration

Routine configuration changes — scaling replicas, adjusting resource limits, modifying load balancer
annotations, etc. — are applied via `helm upgrade` against the same release. The command is the
same for CE and PE; your `values.yaml` already encodes which edition you're running:

```bash
helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster -f values.yaml
```

## Upgrading

A TBMQ chart upgrade may include a database schema migration when the `appVersion` changes. Always
back up your PostgreSQL database before upgrading.

### Backup (Recommended)

Follow the procedure documented by your PostgreSQL provider (operator, cloud-managed service, or
self-managed instance) to create a logical or physical backup before proceeding.

### Standard Upgrade Procedure

The same steps apply to **CE → newer CE** and **PE → newer PE** upgrades — the commands below are
identical for both, because your `values.yaml` already encodes which edition you're running.

1. **Scale `tbmq-node` (and optionally `tbmq-ie`) to 0 replicas** so no application is reading or
   writing while the schema migration runs:

   ```bash
   kubectl scale statefulset/my-tbmq-tbmq-node --replicas=0 -n <namespace>
   # Recommended on TBMQ version bumps (broker ↔ IE protocol coupling):
   kubectl scale statefulset/my-tbmq-tbmq-ie   --replicas=0 -n <namespace>
   ```

   The IE doesn't connect to PostgreSQL itself, so the schema migration doesn't directly affect
   it. Scaling it down is still recommended on TBMQ version bumps, because the IE communicates
   with the broker over Kafka and the message contract / API surface can change between releases
   — leaving the IE running against a freshly upgraded broker (or a broker that's been scaled to
   zero) can produce noisy errors. For routine config-only `helm upgrade`s on the same TBMQ
   version you can leave the IE running.

2. **Run the upgrade.** The `upgrade.upgradeDbSchema=true` flag triggers the pre-upgrade Helm hook
   that runs the migration:

   ```bash
   helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster \
     --version <new-chart-version> \
     -f values.yaml \
     --set upgrade.upgradeDbSchema=true
   ```

   > **Note on PE image tags:** your `values.yaml` pins `tbmq.image.tag` and `tbmq-ie.image.tag`
   > from when you first exported it. When bumping the chart version, also update those tags in
   > your file to match the new chart `appVersion` (`<appVersion>` for CE, `<appVersion>PE` for
   > PE). The canonical PE tags for the target chart version are in
   > [`values-pe.yaml`](values-pe.yaml) at that chart tag.

3. **Verify the migration completed.** The migration runs as a Kubernetes Job named
   `my-tbmq-upgrade-<revision>` and is automatically deleted 5 minutes after it finishes
   (`ttlSecondsAfterFinished: 300`). Tail its logs while it runs:

   ```bash
   kubectl logs job/my-tbmq-upgrade-<revision> -n <namespace> -f
   ```

   Helm restores both StatefulSets to the chart's declared `replicas` value (default `2`) as part
   of the upgrade — no manual scale-back is needed.

### CE → PE Upgrade (Cross-Edition Migration)

Migrating an existing CE release to PE **on the same TBMQ version** is a two-edit change to your
existing `values.yaml` followed by one `helm upgrade` with the cross-edition flag. The flag sets
`FROM_VERSION=ce` on the upgrade Job (forwarded by the PE entrypoint as
`-Dinstall.upgrade.from_version=ce`), triggering the PE-specific schema and data transformations
on top of the existing CE data.

1. **Edit your existing `values.yaml`** to switch to the PE images and add a license. Both edits
   are exactly the same as for a fresh PE install — see
   [Switch to PE images](#1-switch-to-pe-images) and
   [Provide your license](#2-provide-your-license). Do not pass `values-pe.yaml` as a `-f`
   overlay alongside this file.

2. **Scale broker and IE to 0** so nothing is connected to the schema while it migrates:

   ```bash
   kubectl scale statefulset/my-tbmq-tbmq-node --replicas=0 -n <namespace>
   kubectl scale statefulset/my-tbmq-tbmq-ie   --replicas=0 -n <namespace>
   ```

3. **Run the upgrade** with the cross-edition flag:

   ```bash
   helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster \
     -f values.yaml \
     --set upgrade.upgradeDbSchema=true \
     --set upgrade.fromVersion=ce
   ```

What happens during this upgrade:

- The pre-upgrade Job uses the **PE** broker image (because your `values.yaml` now points at PE)
  with `UPGRADE_TB=true` and `FROM_VERSION=ce`. The PE entrypoint reads `FROM_VERSION` and
  appends `-Dinstall.upgrade.from_version=ce` to the install application command line, which
  switches the migration into CE→PE mode (rewrites the CE schema as PE).
- After the migration succeeds, Helm rolls the `tbmq-node` and `tbmq-ie` StatefulSets onto the PE
  images and restores both to the chart's declared `replicas` value — no manual scale-back is
  needed.

After the migration succeeds, **do not** carry `upgrade.fromVersion=ce` forward to subsequent
PE → PE upgrades — drop the flag (or set it to `""`) on the next `helm upgrade`. Leaving it on
will cause the upgrade Job to attempt a CE→PE migration against an already-PE database on every
release, which will fail.

### Upgrading from chart version 1.x to 2.0.0 (TBMQ 2.2.0 → 2.3.0)

Chart version 2.0.0 is a **breaking change**. All Bitnami subchart dependencies (PostgreSQL, Kafka,
Redis Cluster) that earlier chart versions bundled have been removed — the chart now expects you to
bring your own third-party infrastructure. This aligns the Helm deployment with the broader TBMQ
v2.3.0 third-party migration described in the
[official upgrade instructions](https://thingsboard.io/docs/mqtt-broker/install/upgrade-instructions/#third-party-component-updates-in-v230).

| Component        | TBMQ v2.2.0 (chart 1.x bundled)       | TBMQ v2.3.0 (chart 2.0.0 — bring your own) |
|------------------|---------------------------------------|--------------------------------------------|
| **PostgreSQL**   | `bitnami/postgresql` (PostgreSQL 16)  | `postgres:17` (operator or self-managed)   |
| **Kafka**        | `bitnamilegacy/kafka:3.7.0` (KRaft)   | `apache/kafka:4.0.0` (official image)      |
| **Redis/Valkey** | `bitnamilegacy/redis:7.2.5` (cluster) | `valkey/valkey:8.0` (Redis-compatible)     |

Chart 2.0.0 has no `postgresql:`, `kafka:`, or `redis-cluster:` subchart blocks — only top-level
`postgresql:`, `kafka:`, and `redis:` connection sections that point at your existing or newly
provisioned infrastructure.

> **Always back up your PostgreSQL database before upgrading**, regardless of which path you take.

> **Set `tbmq.persistence.enabled: false` in your chart 2.0.0 upgrade values.** Chart 2.0.0 adds a
> per-pod `volumeClaimTemplate` for `/data` on the broker StatefulSet (default
> `tbmq.persistence.enabled: true`). Chart 1.x had no such template (its `/data` was an `emptyDir`),
> and `volumeClaimTemplates` is one of the immutable fields on an existing StatefulSet — adding it
> in place makes `helm upgrade` fail with
> `StatefulSet ... is invalid: spec: Forbidden: updates to statefulset spec for fields other than ... are forbidden`.
> Chart 1.x deployments are CE-only, so disabling persistence on the upgrade is safe (there is no
> PE license cache to preserve).
>
> The pre-upgrade schema migration Job runs **before** the StatefulSet patch. If you hit this error
> on a first attempt the schema is already at the target version, and re-running the upgrade with
> `--set upgrade.upgradeDbSchema=true` will fail its already-upgraded check
> (`database already upgraded to current version`). Retry without `upgradeDbSchema` (and with
> `tbmq.persistence.enabled: false`).
>
> Enabling `tbmq.persistence` later (e.g. before a CE→PE migration on the chart 2.0.0 CE release)
> hits the same immutable-field rule. Take a maintenance window, delete the broker StatefulSet with
> `kubectl delete statefulset <release>-tbmq-node -n <namespace> --cascade=orphan` (this leaves the
> running Pod up while the StatefulSet is gone), then `helm upgrade` with
> `tbmq.persistence.enabled: true` to recreate it with the `volumeClaimTemplate`.

#### Two upgrade paths

**Option A — Keep the existing in-cluster Bitnami stack.** Annotate every Bitnami-rendered
resource in the chart 1.x release with `helm.sh/resource-policy: keep` so `helm upgrade` to chart
2.0.0 does not delete them, then point chart 2.0.0's top-level `postgresql:` / `kafka:` / `redis:`
sections at the still-running in-cluster Services and reuse the Bitnami-created Secrets. The
schema migration runs as the standard pre-upgrade Job. This path keeps PostgreSQL on major version
16 and leaves the Bitnami Pods detached from Helm — long-term, plan to migrate to the official
open-source images (Option B).

> Run `helm get manifest <release> -n <namespace>` first to see the exact list of subchart
> resources in your release and annotate based on that output — names depend on your release name
> and the exact subchart versions you originally installed. Missing a resource means
> `helm upgrade` will delete it.

**Option B — Provision a fresh third-party stack.** The cleaner long-term path: provision the
v2.3.0 reference stack (PostgreSQL 17, Apache Kafka 4.0.0, Valkey 8.0) outside the Helm release,
then run the chart 2.0.0 upgrade pointing at the new infrastructure.

PostgreSQL must carry over (`pg_dump` / `pg_restore`, or the operator equivalent) — it holds the
TBMQ schema and cluster id. For Kafka and Redis you have a choice:

- **Migrate the data.** Choose this if you need to preserve any persisted-but-undelivered MQTT
  messages and the in-cluster MQTT state held outside PostgreSQL. The image transitions
  (`bitnamilegacy/kafka:3.7.0` → `apache/kafka:4.0.0` and `bitnamilegacy/redis:7.2.5` →
  `valkey/valkey:8.0`) do not permit direct volume reuse, so plan a logical export/replay rather
  than a PV swap.
- **Start Kafka and Redis empty.** A valid choice when you accept that any
  persisted-but-undelivered messages are either already delivered or will be dropped. MQTT
  clients reconnect to the new cluster on their own and their subscriptions get re-established as
  they come back online — no operator action required for that.

The [Minikube guide](docs/minikube/README.md) walks through provisioning one such stack
end-to-end (it does not cover Kafka or Redis data migration).

For detailed assistance with either path,
[contact ThingsBoard](https://thingsboard.io/docs/contact-us/).

### Troubleshooting Upgrades

The pre-upgrade migration Job spawns a Pod named `my-tbmq-upgrade-<revision>-<random>`. The Job
itself has `ttlSecondsAfterFinished: 300`, so both Job and Pod are deleted 5 minutes after the
migration finishes — successful or not. Watch logs while the Job runs, or capture them quickly
once it terminates:

```bash
kubectl logs job/my-tbmq-upgrade-<revision> -n <namespace> -f
# or, if the Pod has already finished but hasn't been TTL-reaped yet:
kubectl logs <upgrade-pod-name> -n <namespace>
```

> The Job has `backoffLimit: 3`, and its pod template has `restartPolicy: Never` — on failure the
> Job creates a brand-new pod rather than restarting the container in place, so `kubectl logs
> --previous` doesn't apply here. List all attempts with `kubectl get pods -n <namespace> -l job-name=my-tbmq-upgrade-<revision>`.

Common causes:

- **Pod stuck in `Init:0/1` with `wait-for-postgres` repeatedly logging `waiting for postgres`** →
  PostgreSQL is unreachable. The init container runs `until nc -z $host $port; do echo waiting for
  postgres; sleep 2; done` — it swallows `nc`'s underlying error (no "connection refused" line
  surfaces) and only echoes `waiting for postgres` between retries, and it never times out on its
  own — the Helm hook timeout will fire after 600s. Check `postgresql.host`/`postgresql.port` and
  that the DB is reachable from the TBMQ namespace.
- **Authentication failed** → verify `postgresql.password` or that the `existingSecret` contains
  the expected key.
- **Hook timeout (10 minutes)** → for very large databases, the migration may exceed the default
  600s timeout. Roll back (`helm rollback`) and re-run after addressing the performance bottleneck
  (e.g., increase resources, run `VACUUM`/`ANALYZE` first).
- **CE → PE migration failed** → confirm `upgrade.fromVersion=ce` was set AND that the PE image is
  in use (check the upgrade Pod's `image:` field — it should be `thingsboard/tbmq-pe-node:<tag>`).
- **`upgrade.fromVersion=ce` left set on a follow-up PE → PE upgrade** → the upgrade job will try
  to migrate an already-PE database from CE and fail. Drop the flag.

## Runtime Troubleshooting

Symptoms you may hit on a running cluster (separate from the upgrade-time issues covered in
[Troubleshooting Upgrades](#troubleshooting-upgrades) above).

### Broker exits immediately with `License Error GENERAL_ERROR(300)`

The broker logs:

```
ERROR o.t.m.b.d.s.BasicSubscriptionService - License secret is not provided!
ERROR o.t.m.b.d.s.BasicSubscriptionService - Please provide license.secret property value in thingsboard-mqtt-broker.yml or set TBMQ_LICENSE_SECRET environment variable!
INFO  o.t.m.b.d.s.BasicSubscriptionService - Terminating application due to critical License Error GENERAL_ERROR(300), exit code [-1]
```

PE images require a license value. Either set `license.secret` inline or pre-create a Secret and
point `license.existingSecret` at it (see [PE install — Provide your license](#2-provide-your-license)).
CE images don't need a license — confirm you didn't pull the PE images (`thingsboard/tbmq-pe-*`)
without configuring one.

### Broker crash-loops with `License Error: CLUSTER_ID_MISMATCH(114)`

The license server has bound your TBMQ license to a different cluster id than the one this
broker is presenting. The cluster id lives in PostgreSQL (`tbmq_cluster.cluster_id`, generated
once at install), so a mismatch means that row has changed since the license was activated.
Common causes:

- **PostgreSQL was wiped or recreated.** A fresh database gets a fresh `tbmq_cluster.cluster_id`
  on the next install. The license server still holds the prior binding and rejects the new
  cluster id. Deactivate the prior binding via your license-server admin (or contact
  ThingsBoard) before reinstalling, or restore the original database.
- **DB was restored from a non-matching backup.** Restoring an older or different cluster's
  backup brings back a different `tbmq_cluster.cluster_id`. Either restore the matching backup
  or deactivate the binding and let the new cluster id register.
- **Same license is being activated against a different deployment.** Single-bind licenses can
  only activate against one cluster id at a time. Deactivate the prior binding before
  installing into a new cluster.

Pod recreation, `helm upgrade`, and `/data` being an `emptyDir` do **not** trigger this error —
the cluster id is not stored under `/data`. Losing the per-pod license cache file forces the
broker to re-activate against the license server on the next start; that does **not** change the
cluster id, but it does consume a fresh instance slot against the license's instance cap (see
[Persistence](#persistence) — sustained cache loss can eventually exhaust the cap and require a
license-server admin to clear stale instance bindings).

## Configuration Reference

### Global Parameters

| Parameter                    | Description                                                                                                                                                                          | Default                     |
|------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| **Docker Authentication**    |                                                                                                                                                                                      |                             |
| dockerAuth.registry          | Docker registry for TBMQ images. Used only when supplying credentials.                                                                                                               | https://index.docker.io/v1/ |
| dockerAuth.username          | Docker username. When set, the chart creates a pull Secret named `tbmq.imagePullSecret` (default `regcred`). When empty, no Secret is created — useful when you pre-create your own. | ""                          |
| dockerAuth.password          | Docker password. Used together with `dockerAuth.username` to populate the chart-managed pull Secret.                                                                                 | ""                          |
| **Installation**             |                                                                                                                                                                                      |                             |
| installation.installDbSchema | Initializes the TBMQ DB schema. Pass via `--set` on first install only. The post-install hook is also bound to `post-upgrade` for recovery scenarios.                                | false                       |
| installation.argocd          | Replaces Helm install/upgrade hooks with ArgoCD `Sync` hook annotations on the install pod.                                                                                          | false                       |
| **Upgrade**                  |                                                                                                                                                                                      |                             |
| upgrade.upgradeDbSchema      | Runs the DB migration during `helm upgrade` (pre-upgrade hook). Ignored on first install.                                                                                            | false                       |
| upgrade.argocd               | Replaces Helm pre-upgrade hooks with ArgoCD `PreSync` hook annotations on the upgrade job.                                                                                           | false                       |
| upgrade.fromVersion          | Edition the upgrade is migrating FROM. Set to `"ce"` only for CE → PE cross-edition upgrades. Leave empty for same-edition upgrades.                                                 | ""                          |
| **License (PE only)**        | Required for PE; ignored for CE (when both `secret` and `existingSecret` are empty, the chart skips license wiring).                                                                 |                             |
| license.secret               | License value. When set, the chart creates a Secret `<release>-tbmq-license-secret`. Convenient for testing; the value lands in the helm release manifest.                           | ""                          |
| license.existingSecret       | Name of a pre-existing Kubernetes Secret holding the license. Recommended for production. When set, the chart does NOT create a Secret of its own.                                   | ""                          |
| license.existingSecretLicenseKey | Key inside `existingSecret` that holds the license value. Matches the convention from the official PE k8s manifests.                                                             | "license-key"               |
| license.instanceDataFile     | Path to the per-pod license cache file. Default uses `$(TB_SERVICE_ID)` so each replica gets its own file under `/data`, which is PVC-backed by default (see `tbmq.persistence`).      | "/data/tbmq-instance-license-$(TB_SERVICE_ID).data" |

### TBMQ (Broker) Parameters

| Parameter                               | Description                                                                                                                                                | Default                                 |
|-----------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| **Image**                               |                                                                                                                                                            |                                       |
| tbmq.image.repository                   | Broker image repository. CE: `thingsboard/tbmq-node`. PE: `thingsboard/tbmq-pe-node`.                                                                      | thingsboard/tbmq-node                 |
| tbmq.image.tag                          | Image tag. CE default tracks the chart `appVersion`. PE: `<appVersion>PE` (e.g. `2.3.0PE`).                                                                | 2.3.0                                 |
| tbmq.imagePullSecret                    | Pull secret name referenced by the broker StatefulSet, install Pod, and upgrade Job. Auto-created from `dockerAuth.username`/`password` if those are set; otherwise expected to exist in the namespace already. | regcred                               |
| tbmq.imagePullPolicy                    | Image pull policy.                                                                                                                                         | Always                                |
| **Scaling**                             |                                                                                                                                                            |                                       |
| tbmq.statefulSet.replicas               | Number of broker pods.                                                                                                                                     | 2                                     |
| tbmq.statefulSet.annotations            | Annotations applied to the StatefulSet resource (CI/CD, audit, etc.).                                                                                      | { }                                   |
| tbmq.annotations                        | Annotations applied to broker pods (Prometheus scrape, sidecars, etc.).                                                                                    | { }                                   |
| tbmq.nodeSelector / tbmq.affinity       | Pod scheduling rules.                                                                                                                                      | { }                                   |
| tbmq.restartPolicy                      | Pod restart policy.                                                                                                                                        | Always                                |
| **Ports**                               |                                                                                                                                                            |                                       |
| tbmq.ports                              | Container ports: HTTP 8083, MQTT 1883, MQTTS 8883, MQTT-WS 8084, MQTT-WSS 8085.                                                                            | (see values.yaml)                     |
| **Configuration**                       |                                                                                                                                                            |                                       |
| tbmq.customEnv                          | Map of env vars applied to broker pods, install Pod, and upgrade Job. Wins over keys in any `existing*ConfigMap`.                                          | { }                                   |
| tbmq.existingConfigMap                  | One ConfigMap providing both `conf` (Java opts) and `logback` (logging) keys. Highest priority — when set, the chart skips rendering its default ConfigMaps and ignores the two below. Applies to broker pods and the upgrade Job; the install Pod uses a dedicated minimal `*-install-config`. | ""                                    |
| tbmq.existingJavaOptsConfigMap          | ConfigMap with a `conf` key providing Java options. Used only when `existingConfigMap` is empty.                                                           | ""                                    |
| tbmq.existingLogbackConfigMap           | ConfigMap with a `logback` key providing logback XML. Used only when `existingConfigMap` is empty.                                                          | ""                                    |
| tbmq.enableChecksumAnnotations          | Auto-restart pods on relevant ConfigMap/Secret changes during `helm upgrade`. Logback is intentionally excluded — TBMQ hot-reloads logback every 10s.       | true                                  |
| **Health checks**                       |                                                                                                                                                            |                                       |
| tbmq.readinessProbe                     | Default: TCP 1883, initialDelay 30s, period 20s, failure threshold 5.                                                                                      | (see values.yaml)                     |
| tbmq.livenessProbe                      | Default: TCP 1883, initialDelay 60s, period 10s, failure threshold 10.                                                                                     | (see values.yaml)                     |
| **Security & resources**                |                                                                                                                                                            |                                       |
| tbmq.securityContext                    | Defaults: `runAsUser: 799`, `runAsNonRoot: true`, `fsGroup: 799`.                                                                                          | (see values.yaml)                     |
| tbmq.resources                          | CPU/memory requests and limits. Set explicitly for production.                                                                                             | { }                                   |
| **Persistence**                         |                                                                                                                                                            |                                       |
| tbmq.persistence.enabled                | Back the broker `/data` directory with a per-pod PVC (via `volumeClaimTemplate`). **Strongly recommended for PE**: without persisted `/data`, each Pod restart re-activates against the license server as a new instance and consumes a fresh slot against the license cap (the license client has no automatic stale-instance cleanup — see [Persistence](#persistence)). Cluster id itself lives in PostgreSQL, not `/data`. Safe to leave on for CE. | true |
| tbmq.persistence.size                   | PVC size. The PE license cache file is a few KB; 1Gi just leaves headroom for any future PE feature that may write to `/data`. The reference PE Kubernetes manifests request 100Mi — bumping this default does not affect compatibility. | "1Gi"                                 |
| tbmq.persistence.storageClassName       | StorageClass name. Empty means use the cluster's default StorageClass.                                                                                       | ""                                    |
| tbmq.persistence.accessModes            | PVC access modes. ReadWriteOnce is correct for per-pod claims.                                                                                              | ["ReadWriteOnce"]                     |

### TBMQ Integration Executor Parameters

The `tbmq-ie` parameters mirror `tbmq` parameters above. Notable differences:

| Parameter                       | Description                                                                                                                                                | Default                               |
|---------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| tbmq-ie.image.repository        | IE image. CE: `thingsboard/tbmq-integration-executor`. PE: `thingsboard/tbmq-pe-integration-executor`.                                                     | thingsboard/tbmq-integration-executor |
| tbmq-ie.image.tag               | Image tag. CE default tracks the chart `appVersion`. PE: `<appVersion>PE` (e.g. `2.3.0PE`).                                                                | 2.3.0                                 |
| tbmq-ie.imagePullSecret         | Pull secret name referenced by the IE StatefulSet only — independent of `tbmq.imagePullSecret`. The chart auto-creates **only one** Secret (named after `tbmq.imagePullSecret`, when `dockerAuth.username` is set). If `tbmq-ie.imagePullSecret` differs, pre-create that Secret yourself. | regcred                               |
| tbmq-ie.imagePullPolicy         | Image pull policy.                                                                                                                                          | Always                                |
| tbmq-ie.statefulSet.replicas    | Number of IE pods.                                                                                                                                          | 2                                     |
| tbmq-ie.ports                   | HTTP 8082.                                                                                                                                                 |                                       |
| tbmq-ie.readinessProbe          | Default: TCP `http`, period 20s.                                                                                                                            |                                       |
| tbmq-ie.livenessProbe           | Default: TCP `http`, initialDelay 120s, period 20s.                                                                                                         |                                       |

> All other `tbmq-ie.*` keys mirror their `tbmq.*` counterparts with the same defaults and behavior:
> `statefulSet.annotations`, `annotations`, `nodeSelector`, `affinity`, `customEnv`,
> `existingConfigMap`, `existingJavaOptsConfigMap`, `existingLogbackConfigMap`,
> `enableChecksumAnnotations`, `restartPolicy`, `securityContext`, `resources`. The IE Pod does
> **not** mount PostgreSQL, Redis, or PE license env vars — it only connects to Kafka.

> **Note:** `tbmq-ie` is referenced in templates with `index .Values "tbmq-ie"` because of the
> hyphen in the key name. The hyphen does not need escaping on the command line — use the
> dotted path directly: `--set tbmq-ie.statefulSet.replicas=3`.

### Persistence

The broker StatefulSet provisions a per-pod PVC for `/data` via `volumeClaimTemplate`.
**Professional Edition** deployments should keep this enabled (the chart default). The license
client writes a per-pod activation-response cache to
`/data/tbmq-instance-license-$(TB_SERVICE_ID).data` on first start. On subsequent starts:

- **With the cache file present**, the broker calls `checkInstance` against the license server,
  reusing its existing `instanceId`. No new slot is consumed.
- **With the cache file missing**, the broker calls `activateInstance` and the license server
  issues a **fresh** `instanceId`, counting against the license's instance cap
  (`MAX_PROD_INSTANCES`).

The TBMQ cluster id itself lives in PostgreSQL (`tbmq_cluster.cluster_id`), not under `/data`,
so cache loss does **not** change cluster identity or trigger `CLUSTER_ID_MISMATCH`. But the
license client has no automatic mechanism to free up slots held by instances that no longer
exist, so repeated activations from sustained cache loss accumulate on the license server until they
exhaust the cap. Once exhausted, new pods cannot activate and a license-server admin has to
clear the stale instance bindings before the cluster can recover. Persisting `/data` avoids the
problem entirely.

For Community Edition, nothing meaningful is persisted under `/data`, so disabling
persistence is safe:

```yaml
tbmq:
  persistence:
    enabled: false
```

The Integration Executor StatefulSet and the pre-upgrade Job continue to use `emptyDir`
for `/data` — they don't carry per-instance state. The install Pod doesn't mount `/data`
at all (its only volumes are the install ConfigMap and a logs `emptyDir`).

**Cleanup.** `helm uninstall` does **not** delete PVCs created by `volumeClaimTemplate`.
The chart-managed PVCs are named `<release>-tbmq-node-data-<release>-tbmq-node-<ordinal>`
(one per broker replica) and carry no `app=...` label, so reap them by name pattern:

```bash
kubectl get pvc -n <namespace> -o name | grep tbmq-node-data \
  | xargs -r kubectl delete -n <namespace>
```

Or simply `kubectl delete namespace <namespace>` if you no longer need the data.

## Infrastructure Configuration

### PostgreSQL

| Parameter                              | Description                                                                                  | Default                   |
|----------------------------------------|----------------------------------------------------------------------------------------------|---------------------------|
| postgresql.host                        | PostgreSQL hostname or service name.                                                         | ""                        |
| postgresql.port                        | PostgreSQL port.                                                                             | 5432                      |
| postgresql.database                    | Database name. Must exist before install (the chart creates the schema, not the database).  | "thingsboard_mqtt_broker" |
| postgresql.username                    | PostgreSQL username.                                                                         | "postgres"                |
| postgresql.password                    | PostgreSQL password. Ignored if `existingSecret` is set. Stored in a chart-managed Secret.   | ""                        |
| postgresql.existingSecret              | Name of an existing Secret holding the password. Recommended for production.                | ""                        |
| postgresql.existingSecretPasswordKey   | Key inside `existingSecret` that holds the password. Falls back to `postgres-password` if left empty. | ""                        |

```yaml
postgresql:
  host: "my-postgres.example.com"
  port: 5432
  database: "thingsboard_mqtt_broker"
  username: "postgres"
  existingSecret: "my-pg-secret"
  existingSecretPasswordKey: "password"
```

### Kafka

| Parameter              | Description                                                | Default |
|------------------------|------------------------------------------------------------|---------|
| kafka.bootstrapServers | Comma-separated `host:port` list of Kafka bootstrap nodes. | ""      |

```yaml
kafka:
  bootstrapServers: "kafka-0:9092,kafka-1:9092,kafka-2:9092"
```

### Redis / Valkey / Cache

TBMQ speaks the Redis protocol. Any Redis-compatible backend (Redis, Valkey, Dragonfly, KeyDB)
works. Two connection modes are supported.

| Parameter                       | Description                                                                                              | Default    |
|---------------------------------|----------------------------------------------------------------------------------------------------------|------------|
| redis.connectionType            | `"standalone"` (single-node) or `"cluster"` (Redis Cluster).                                             | "cluster"  |
| redis.host                      | Hostname for `standalone` mode.                                                                          | ""         |
| redis.port                      | Port for `standalone` mode.                                                                              | 6379       |
| redis.nodes                     | Comma-separated `host:port` list for `cluster` mode.                                                     | ""         |
| redis.usePassword               | Whether the cache requires password authentication.                                                      | true       |
| redis.password                  | Password. Ignored if `existingSecret` is set. Stored in a chart-managed Secret.                          | ""         |
| redis.existingSecret            | Name of an existing Secret holding the password.                                                         | ""         |
| redis.existingSecretPasswordKey | Key inside `existingSecret` that holds the password. Falls back to `redis-password` if left empty.       | ""         |

**Cluster mode:**

```yaml
redis:
  connectionType: "cluster"
  nodes: "redis-0:6379,redis-1:6379,redis-2:6379,redis-3:6379,redis-4:6379,redis-5:6379"
  existingSecret: "my-redis-secret"
  existingSecretPasswordKey: "redis-password"
```

**Standalone mode (e.g., single-node Valkey):**

```yaml
redis:
  connectionType: "standalone"
  host: "valkey.example.com"
  port: 6379
  usePassword: false
```

In `cluster` mode, the chart automatically renders cluster-only keys (`REDIS_NODES`,
`REDIS_MAX_REDIRECTS`, `REDIS_CLUSTER_USE_DEFAULT_POOL_CONFIG`, and the Lettuce/Jedis topology
refresh tunables) into the Redis ConfigMap; in `standalone` mode those keys are omitted and only
`REDIS_HOST`/`REDIS_PORT` are set.

## Load Balancer

The chart creates Kubernetes `Ingress` (for HTTP) and `Service` (for MQTT) resources. It does
**not** deploy the load balancer or ingress controller itself — those must already exist in your
cluster (NGINX Ingress Controller, AWS Load Balancer Controller, Application Gateway Ingress
Controller, etc.).

| Parameter                                               | Description                                                                                              | Default                |
|---------------------------------------------------------|----------------------------------------------------------------------------------------------------------|------------------------|
| loadbalancer.type                                       | Provider flavor: `"nginx"`, `"aws"`, `"azure"`, `"gcp"`. Selects template variant + default annotations. | "nginx"                |
| loadbalancer.http.enabled                               | Create the HTTP Ingress.                                                                                 | true                   |
| loadbalancer.http.annotations                           | Extra Ingress annotations. Merged with provider defaults — user values win on conflict.                  | { }                    |
| loadbalancer.http.ssl.enabled                           | Enable HTTPS termination at the load balancer. Honored by `aws`, `azure`, and `gcp` flavors; the `nginx` template does not implement HTTPS termination and ignores this key. | false                  |
| loadbalancer.http.ssl.certificateRef                    | Cert reference: AWS ACM ARN, Azure `appgw-ssl-certificate` value, GCP `ManagedCertificate` name.        | ""                     |
| loadbalancer.http.ssl.domains                           | Domains for HTTPS. Required for GCP `ManagedCertificate`.                                                | ["www.example.com"]    |
| loadbalancer.http.ssl.staticIP                          | GCP-only: static IP name for the HTTP(S) load balancer.                                                  | "tbmq-http-lb-address" |
| loadbalancer.mqtt.enabled                               | Create the MQTT LoadBalancer Service.                                                                    | true                   |
| loadbalancer.mqtt.annotations                           | Extra Service annotations. Merged with provider defaults — user values win on conflict.                  | { }                    |
| loadbalancer.mqtt.mutualTls.enabled                     | Enable application-level mTLS. Requires server cert + key. Disables `tlsTermination`.                    | false                  |
| loadbalancer.mqtt.mutualTls.configMapName               | ConfigMap with `server.pem` and `mqttserver_key.pem` keys.                                               | "tbmq-node-mqtts-config" |
| loadbalancer.mqtt.mutualTls.privateKeyPasswordSecret    | Optional Secret holding the private key password.                                                        | ""                     |
| loadbalancer.mqtt.mutualTls.privateKeyPasswordSecretKey | Key inside the Secret with the private key password.                                                     | "key_password"         |
| loadbalancer.mqtt.tlsTermination.enabled                | Enable L4 TLS termination at the load balancer. Supported on AWS NLB only. Ignored if mTLS is enabled.   | false                  |
| loadbalancer.mqtt.tlsTermination.certificateRef         | AWS NLB ACM certificate ARN.                                                                             | ""                     |

## Mutual TLS (mTLS) for MQTT

To enable application-level mTLS for the MQTT listener:

1. Create a ConfigMap holding the server certificate and private key:

   ```bash
   kubectl create configmap tbmq-node-mqtts-config \
     --from-file=server.pem=/path/to/server.pem \
     --from-file=mqttserver_key.pem=/path/to/mqttserver_key.pem \
     -o yaml --dry-run=client | kubectl apply -f -
   ```

2. (Optional) If the private key is password-protected, create a Secret:

   ```bash
   kubectl create secret generic mqtt-tls-secret \
     --from-literal=key_password="YOUR_KEY_PASSWORD" \
     -o yaml --dry-run=client | kubectl apply -f -
   ```

3. Enable mTLS in your `values.yaml`:

   ```yaml
   loadbalancer:
     mqtt:
       enabled: true
       mutualTls:
         enabled: true
         configMapName: "tbmq-node-mqtts-config"
         privateKeyPasswordSecret: "mqtt-tls-secret"      # omit if not needed
         privateKeyPasswordSecretKey: "key_password"      # omit if not needed
   ```

## Uninstalling

```bash
helm uninstall my-tbmq -n <namespace>
```

`helm uninstall` removes the Kubernetes resources owned by the release (StatefulSets, Services,
ConfigMaps, chart-managed Secrets, Ingress, and the load balancer Service). It does **not** touch:

- **External infrastructure** — PostgreSQL data, Kafka topics, and Redis cache are owned by the
  systems you deployed alongside TBMQ. Drop them explicitly if you no longer need them.
- **Pre-existing Secrets** — anything referenced via `postgresql.existingSecret`,
  `redis.existingSecret`, or a pre-created `tbmq.imagePullSecret` is left in place.
- **Per-pod PVCs created from `volumeClaimTemplate`** — chart-managed `tbmq-node-data` PVCs are not deleted by `helm uninstall`. They carry no `app=...` label (the volumeClaimTemplate has none), so drop them explicitly by name pattern: `kubectl get pvc -n <namespace> -o name | grep tbmq-node-data | xargs -r kubectl delete -n <namespace>`, or just delete the whole namespace.
