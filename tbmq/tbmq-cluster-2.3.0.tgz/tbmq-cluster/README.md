# Helm Chart for TBMQ Cluster

TBMQ is a high-performance MQTT message broker capable of handling 4M+ concurrent client connections,
delivering 3M+ messages per second per single cluster node with low latency. In cluster mode,
TBMQ scales to 100M+ concurrently connected clients.

This chart deploys a TBMQ cluster on Kubernetes. The same chart supports both editions of TBMQ:

- **Community Edition (CE)** — open-source, default images.
- **Professional Edition (PE)** — commercial edition with additional features. Enabled by switching
  the broker and integration-executor images to the PE variants in your `values.yaml` and supplying
  a license. All templates, configuration keys, and operational behavior are identical between
  editions. See [Professional Edition (PE)](#professional-edition-pe) under "Installing" for the
  exact edits.

**Documentation & Resources:**

- TBMQ [Documentation](https://tbmq.io/)
- TBMQ GitHub [Repository](https://github.com/thingsboard/tbmq)
- ThingsBoard Charts GitHub [Repository](https://github.com/thingsboard/helm-charts)

> **Trademarks:** This software listing is packaged by the TBMQ Team. The respective trademarks
> mentioned in the offering are owned by the respective companies, and use of them does not imply
> any affiliation or endorsement.

## Architecture

The chart deploys only TBMQ application components:

- `tbmq-node` — broker StatefulSet (default 2 replicas). Exposes MQTT (1883), MQTTS (8883), MQTT-WS
  (8084), MQTT-WSS (8085), and an HTTP management API (8083).
- `tbmq-ie` — Integration Executor StatefulSet (default 2 replicas). Exposes HTTP (8082).
- Helm hooks for one-shot install Pod and upgrade Job that run TBMQ's database schema initializer
  or migration tool.
- Optional `Ingress` and `Service` resources for HTTP and MQTT load balancing
  (`nginx`, `aws`, `azure`, or `gcp` flavors).

Infrastructure dependencies — PostgreSQL, Kafka, and a Redis-compatible cache — must be deployed
separately. Use whatever fits your environment: operators (CrunchyData PGO, Strimzi, Valkey
Operator), managed services (RDS, MSK, ElastiCache), or raw manifests. The chart connects to your
existing instances via the values you provide.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.8.0+
- A default StorageClass (or set `tbmq.persistence.storageClassName`) — the broker requests a
  per-pod PVC for `/data` by default. See [Persistence](#persistence).
- An external PostgreSQL instance with an empty database created for TBMQ (default name
  `thingsboard_mqtt_broker`, set via `postgresql.database`). The chart creates the schema, not the
  database.
- An external Kafka cluster
- An external Redis-compatible cache (Redis, Valkey, Dragonfly, etc.) — standalone or cluster
- For the default load balancer settings: an NGINX Ingress Controller for HTTP, and support for
  `Service` type `LoadBalancer` for MQTT. Other options are covered in
  [Step 2](#step-2-prepare-your-valuesyaml) and [Load Balancer](#load-balancer).

For a working step-by-step example using Minikube with CrunchyData PGO, Strimzi Kafka, and Valkey,
see the [Minikube Deployment Guide](docs/minikube/README.md).

## Installing

### Step 1: Add the TBMQ Helm Repository

```bash
helm repo add tbmq-helm-chart https://helm.thingsboard.io/tbmq
helm repo update
```

### Step 2: Prepare Your `values.yaml`

Export the chart defaults as a starting point, then edit it to match your environment:

```bash
helm show values tbmq-helm-chart/tbmq-cluster > values.yaml
```

> The exported file pins every default at the chart version you exported it from, including the
> TBMQ image tags (`tbmq.image.tag`, `tbmq-ie.image.tag`) and the helper image versions
> (`helperImages.*`). Installing a newer chart version does not change them in your file — you
> update them yourself when you upgrade (see [Standard Upgrade Procedure](#standard-upgrade-procedure)).

At a minimum you need to set:

- `postgresql.host` and credentials (or `existingSecret`)
- `kafka.bootstrapServers`
- `redis.nodes` (cluster mode is the default) — or `redis.connectionType: standalone` plus
  `redis.host`/`redis.port` — and credentials if `usePassword: true`
- `loadbalancer.type` — the default `nginx` needs an NGINX Ingress Controller already running in
  the cluster, and the MQTT `Service` of type `LoadBalancer` stays `<pending>` on clusters without
  a load balancer provider. Pick `aws`, `azure`, or `gcp` for those clouds, or set
  `loadbalancer.http.enabled: false` and `loadbalancer.mqtt.enabled: false` and reach TBMQ with
  `kubectl port-forward` (see [Step 5](#step-5-access-tbmq)).

The connection settings for PostgreSQL, Kafka, and Redis are described below.

> **Important:** Do not set `installation.installDbSchema: true` in `values.yaml`. Pass it via
> `--set` on the `helm install` command instead. Persisting it in your values file means the install
> pod will also run on every subsequent `helm upgrade` (because the post-install hook is also bound
> to `post-upgrade` to allow recovery from a forgotten flag).

#### PostgreSQL

| Parameter                              | Description                                                                                  | Default                   |
|----------------------------------------|----------------------------------------------------------------------------------------------|---------------------------|
| postgresql.host                        | PostgreSQL hostname or service name.                                                         | ""                        |
| postgresql.port                        | PostgreSQL port.                                                                             | 5432                      |
| postgresql.database                    | Database name. Must exist before install (the chart creates the schema, not the database).  | "thingsboard_mqtt_broker" |
| postgresql.username                    | PostgreSQL username.                                                                         | "postgres"                |
| postgresql.password                    | PostgreSQL password. Ignored if `existingSecret` is set. Stored in a chart-managed Secret.   | ""                        |
| postgresql.existingSecret              | Name of an existing Secret, in the release namespace, holding the password. Recommended for production. | ""                        |
| postgresql.existingSecretPasswordKey   | Key inside `existingSecret` that holds the password. Falls back to `postgres-password` if left empty. | ""                        |

```yaml
postgresql:
  host: "my-postgres.example.com"
  port: 5432
  database: "thingsboard_mqtt_broker"
  username: "postgres"
  existingSecret: "my-pg-secret"
  existingSecretPasswordKey: "password"
```

#### Kafka

| Parameter              | Description                                                | Default |
|------------------------|------------------------------------------------------------|---------|
| kafka.bootstrapServers | Comma-separated `host:port` list of Kafka bootstrap nodes. | ""      |

```yaml
kafka:
  bootstrapServers: "kafka-0:9092,kafka-1:9092,kafka-2:9092"
```

#### Redis / Valkey / Cache

TBMQ speaks the Redis protocol. Any Redis-compatible backend (Redis, Valkey, Dragonfly, KeyDB)
works. Two connection modes are supported.

| Parameter                       | Description                                                                                              | Default    |
|---------------------------------|----------------------------------------------------------------------------------------------------------|------------|
| redis.connectionType            | `"standalone"` (single-node) or `"cluster"` (Redis Cluster).                                             | "cluster"  |
| redis.host                      | Hostname for `standalone` mode.                                                                          | ""         |
| redis.port                      | Port for `standalone` mode.                                                                              | 6379       |
| redis.nodes                     | Comma-separated `host:port` list for `cluster` mode.                                                     | ""         |
| redis.usePassword               | Whether the cache requires password authentication.                                                      | true       |
| redis.password                  | Password. Ignored if `existingSecret` is set. Stored in a chart-managed Secret.                          | ""         |
| redis.existingSecret            | Name of an existing Secret, in the release namespace, holding the password.                              | ""         |
| redis.existingSecretPasswordKey | Key inside `existingSecret` that holds the password. Falls back to `redis-password` if left empty.       | ""         |

**Cluster mode:**

```yaml
redis:
  connectionType: "cluster"
  nodes: "redis-0:6379,redis-1:6379,redis-2:6379,redis-3:6379,redis-4:6379,redis-5:6379"
  existingSecret: "my-redis-secret"
  existingSecretPasswordKey: "redis-password"
```

**Standalone mode (e.g., single-node Valkey):**

```yaml
redis:
  connectionType: "standalone"
  host: "valkey.example.com"
  port: 6379
  usePassword: false
```

In `cluster` mode, the chart automatically renders cluster-only keys (`REDIS_NODES`,
`REDIS_MAX_REDIRECTS`, `REDIS_CLUSTER_USE_DEFAULT_POOL_CONFIG`, and the Lettuce topology
refresh tunables) into the Redis ConfigMap; in `standalone` mode those keys are omitted and only
`REDIS_HOST`/`REDIS_PORT` are set.

#### Professional Edition (PE)

Skip this section for CE. PE installs from the same chart; you configure it with two more edits
to the same `values.yaml`:

1. Switch the broker and integration-executor images to the PE variants.
2. Provide a license.

> The repo ships [`values-pe.yaml`](values-pe.yaml) as a **reference** for the canonical PE image
> repositories and tags at the current chart version. Copy those values into your `values.yaml`;
> do not pass `values-pe.yaml` itself as a `-f` overlay alongside your file.

##### Switch to PE images

Find the `tbmq.image` and `tbmq-ie.image` blocks in your `values.yaml` and change `repository`
and `tag` to the PE values:

```yaml
tbmq:
  image:
    repository: thingsboard/tbmq-pe-node                  # was: thingsboard/tbmq-node
    tag: 2.4.0PE                                          # was: 2.4.0

tbmq-ie:
  image:
    repository: thingsboard/tbmq-pe-integration-executor  # was: thingsboard/tbmq-integration-executor
    tag: 2.4.0PE                                          # was: 2.4.0
```

PE tags match the chart `appVersion` with a `PE` suffix (e.g. `2.4.0` → `2.4.0PE`). The CE and PE
image tags are **not** interchangeable.

##### Provide your license

**Recommended (production):** keep the license out of `values.yaml` by pre-creating a Kubernetes
Secret **in the namespace you will install into** and referencing it from values:

```bash
kubectl create namespace <namespace>
kubectl create secret generic my-tbmq-license -n <namespace> \
  --from-literal=license-key='YOUR_LICENSE_VALUE'
```

```yaml
license:
  existingSecret: my-tbmq-license
  # The chart reads the license from a key named "license-key" inside the Secret.
  # If your Secret uses a different key, set existingSecretLicenseKey: <your-key>.
```

Why this is the recommended path:

- The license value never lives in `values.yaml` on disk, so the file is safe to keep in version
  control alongside the rest of your infra config.
- Composes with sealed-secrets, External Secrets Operator, SOPS, Vault, or any other tool that
  produces a Kubernetes Secret in the release's namespace — point `existingSecret` at the name
  it produces and the chart picks it up unchanged.
- Rotating the license is `kubectl edit secret` plus a broker restart
  (`kubectl rollout restart statefulset/<release>-tbmq-node -n <namespace>`) — no `helm upgrade`
  round-trip. The broker reads the Secret only when its container starts.
- The Secret survives `helm uninstall`, so reinstalling the release does not require re-pasting
  the license value.

**Alternative (test / dev):** paste the license value into your `values.yaml` and the chart will
render the Secret for you (`<release>-tbmq-license-secret`):

```yaml
license:
  secret: YOUR_LICENSE_VALUE
```

This is fine for quick experiments, but the value lands inside the helm release manifest stored
in the cluster (`sh.helm.release.v1.<name>.<rev>` Secret), and anyone with `get secrets`
permission in that namespace can read it back.

Only the broker validates the license, so the chart wires it **only** into the broker
StatefulSet (the IE, install Pod, and upgrade Job don't use it). Each broker Pod also keeps a
small license cache file under `/data`. Keep `tbmq.persistence.enabled: true` (the default) for
PE: without a persisted cache, every Pod restart uses up a new instance slot on your license.
See [Persistence](#persistence) for details.

### Step 3: Install

The command is the same for CE and PE — your `values.yaml` encodes which edition you're running:

```bash
helm install my-tbmq tbmq-helm-chart/tbmq-cluster \
  -n <namespace> --create-namespace \
  -f values.yaml \
  --set installation.installDbSchema=true
```

- `my-tbmq` is the **Helm release name**. Pick any name. It is used as the prefix for all deployed
  resources and as the reference for future `helm` commands against this release.
- `-n <namespace>` must be the same namespace on every later `helm` and `kubectl` command. For PE
  it must be the namespace that holds your license Secret.
- Helm waits for the schema install hook up to its `--timeout` (default 5m). The install Pod's
  own limit, `installation.activeDeadlineSeconds`, is set below that by default (see
  [Global Parameters](#global-parameters)), so no `--timeout` is needed. If you raise the limit
  (e.g. for slow image pulls), also pass a `--timeout` comfortably longer than it; an equal
  timeout expires first and hides the real error.

### Step 4: Verify the Install

```bash
# List the broker, integration executor, and install-pod resources
kubectl get pods -n <namespace> -l 'app in (my-tbmq-tbmq-node,my-tbmq-tbmq-ie,install-job)'
```

The chart labels its Pods only with `app: <name>` (there is no `app.kubernetes.io/instance`
label), so the selector lists the three app names instead of filtering by release.

The install pod (`my-tbmq-install-pod`) creates the schema, then exits. Its `restartPolicy` is
`OnFailure`, so a failed container restarts in the same Pod until it succeeds or
`installation.activeDeadlineSeconds` passes; after that the Pod is marked `Failed`.
The hook policy is `hook-succeeded,before-hook-creation`: Helm deletes the pod **only when it
succeeds**. A failed pod is **left in place** so you can inspect logs, and it is cleaned up the
next time the hook runs (e.g., the next `helm upgrade`) or when you delete it.

The `my-tbmq-tbmq-node-*` (broker) pods block in their `validate-db` init container until the
schema exists, so they reach `Running` within a minute or two **after** the install pod succeeds.
The `my-tbmq-tbmq-ie-*` pods have no PostgreSQL dependency and may already be `Running` before
the install pod completes.

```bash
# Follow the install while it runs:
kubectl logs my-tbmq-install-pod -n <namespace> -f
```

If an attempt fails, read the logs while the Pod is still retrying. Between attempts, plain
`kubectl logs my-tbmq-install-pod -n <namespace>` shows the failed attempt; once the next attempt
has started, add `--previous` to see the failed one. Don't wait for the deadline: the attempt
running when `installation.activeDeadlineSeconds` passes is killed mid-run, so the log left
behind may not show the cause.

If something goes wrong, see [Troubleshooting the Install](#troubleshooting-the-install).

### Step 5: Access TBMQ

**Web UI and REST API** (port 8083). With the default `nginx` load balancer, open the address of
the `my-tbmq-http-lb` Ingress:

```bash
kubectl get ingress my-tbmq-http-lb -n <namespace>
```

Without a load balancer, forward the port locally and open `http://localhost:8083`:

```bash
kubectl port-forward svc/my-tbmq-tbmq-node 8083:8083 -n <namespace>
```

Log in with the default system administrator account and **change the password immediately**:

- Email: `sysadmin@thingsboard.org`
- Password: `sysadmin`

**MQTT** (port 1883, 8883 for MQTTS). With the MQTT load balancer enabled, use the external address
of the `my-tbmq-mqtt-lb` Service:

```bash
kubectl get service my-tbmq-mqtt-lb -n <namespace>
```

Without a load balancer, use `kubectl port-forward svc/my-tbmq-tbmq-node 1883:1883 -n <namespace>`.

MQTT clients must authenticate. Client credentials are managed in the TBMQ UI or REST API, not in
the chart — see [Getting Started](https://tbmq.io/docs/getting-started/) and
[MQTT client credentials](https://tbmq.io/docs/user-guide/ui/mqtt-client-credentials/) to connect a
first client.

### Troubleshooting the Install

- **Install Pod stuck in `Init:0/1` with `wait-for-postgres` repeatedly logging `waiting for postgres`**
  → PostgreSQL is unreachable. The init container runs `until nc -z $host $port; do echo waiting for
  postgres; sleep 2; done`. An unresolvable host also logs `nc: bad address '<host>'`; a refused or
  timed-out connection logs nothing but `waiting for postgres`. Check `postgresql.host` /
  `postgresql.port` and that the database is reachable from the TBMQ namespace. The Pod stops when
  `installation.activeDeadlineSeconds` passes.
- **Authentication failed** in the install Pod logs → verify `postgresql.password`, or that
  `existingSecret` contains the expected key (`existingSecretPasswordKey`, default
  `postgres-password`).
- **`database "thingsboard_mqtt_broker" does not exist`** → create the database first; the chart
  only creates the schema.
- **`helm install` fails with `INSTALLATION FAILED: failed post-install: … pod my-tbmq-install-pod failed`,
  or `failed post-install: timed out waiting for the condition`** → the install hook did not
  succeed. The first error means the Pod reached `installation.activeDeadlineSeconds`
  (`kubectl describe pod` shows `DeadlineExceeded`); the second means Helm's `--timeout`
  (default 5m) ran out first. The same Pod failing during a `helm upgrade` (the forgotten-flag
  recovery below) shows up as `post-upgrade hooks failed`. Find the cause in the causes above
  (see [Step 4](#step-4-verify-the-install) for reading the logs), fix it, then
  `helm uninstall my-tbmq -n <namespace>` and run the Step 3 install command again. `helm uninstall`
  leaves the failed install Pod in place; the next install replaces it.
- **Broker pods stuck in `Init:0/1` (`validate-db`)** → the schema was never created. Check that
  you passed `--set installation.installDbSchema=true` and that the install Pod succeeded. If you
  forgot the flag, run it through an upgrade (the install hook is also bound to `post-upgrade` for
  this recovery):
  `helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster -n <namespace> -f values.yaml --set installation.installDbSchema=true`

## Updating Configuration

Routine configuration changes — scaling replicas, adjusting resource limits, modifying load balancer
annotations, etc. — are applied via `helm upgrade` against the same release. The command is the
same for CE and PE; your `values.yaml` already encodes which edition you're running:

```bash
helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster -n <namespace> -f values.yaml
```

## Upgrading

A TBMQ chart upgrade may include a database schema migration when the `appVersion` changes. Always
back up your PostgreSQL database before upgrading.

### Backup (Recommended)

Follow the procedure documented by your PostgreSQL provider (operator, cloud-managed service, or
self-managed instance) to create a logical or physical backup before proceeding.

### Standard Upgrade Procedure

The same steps apply to **CE → newer CE** and **PE → newer PE** upgrades.

1. **Check whether the TBMQ version changes.** Compare the `APP VERSION` of your release with the
   target chart's:

   ```bash
   helm list -n <namespace>
   helm search repo tbmq-helm-chart/tbmq-cluster --versions
   ```

   - **Same `APP VERSION`** (for example chart 2.1.0 → 2.2.0, both TBMQ 2.4.0): there is no
     schema to migrate. Do steps 2 and 3 only.
   - **Different `APP VERSION`**: do all the steps.

2. **Update your `values.yaml`.** Your file pins the image tags and helper image versions from
   when you exported it. Compare it with the new chart's defaults and carry over what changed:

   ```bash
   helm show values tbmq-helm-chart/tbmq-cluster --version <new-chart-version> > values-new.yaml
   diff values.yaml values-new.yaml
   ```

   In particular, set `tbmq.image.tag` and `tbmq-ie.image.tag` to the new `appVersion`
   (`<appVersion>` for CE, `<appVersion>PE` for PE). Otherwise the chart upgrade keeps running the
   old TBMQ images. The canonical PE tags for a chart version are in
   [`values-pe.yaml`](values-pe.yaml) at that chart tag.

3. **Same `APP VERSION` only — run a plain upgrade and stop here:**

   ```bash
   helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster \
     -n <namespace> \
     --version <new-chart-version> \
     -f values.yaml
   ```

   Do **not** pass `upgrade.upgradeDbSchema=true` here: the pre-upgrade Job fails with
   `database already upgraded to current version` and the release is left `failed` (see
   [Troubleshooting Upgrades](#troubleshooting-upgrades)). The one same-version upgrade that does
   use the flag is the [CE → PE migration](#ce--pe-upgrade-cross-edition-migration).

4. **Scale `tbmq-node` (and optionally `tbmq-ie`) to 0 replicas** so no application is reading or
   writing while the schema migration runs:

   ```bash
   kubectl scale statefulset/my-tbmq-tbmq-node --replicas=0 -n <namespace>
   # Recommended on TBMQ version bumps (broker ↔ IE protocol coupling):
   kubectl scale statefulset/my-tbmq-tbmq-ie   --replicas=0 -n <namespace>
   ```

   The IE doesn't connect to PostgreSQL itself, so the schema migration doesn't directly affect
   it. Scaling it down is still recommended on TBMQ version bumps, because the IE communicates
   with the broker over Kafka and the message contract / API surface can change between releases
   — leaving the IE running against a freshly upgraded broker (or a broker that's been scaled to
   zero) can produce noisy errors.

5. **Run the upgrade.** The `upgrade.upgradeDbSchema=true` flag triggers the pre-upgrade Helm hook
   that runs the migration:

   ```bash
   helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster \
     -n <namespace> \
     --version <new-chart-version> \
     -f values.yaml \
     --set upgrade.upgradeDbSchema=true
   ```

   Helm waits for the migration up to its `--timeout` (default 5m). The migration Job's own limit,
   `upgrade.activeDeadlineSeconds`, is set below that by default (see
   [Global Parameters](#global-parameters)), so no `--timeout` is needed. If you raise the limit,
   also pass a `--timeout` comfortably longer than it; otherwise Helm gives up first while the
   migration keeps running (see [Troubleshooting Upgrades](#troubleshooting-upgrades)).

6. **Verify the migration completed.** The migration runs as a Kubernetes Job named
   `my-tbmq-upgrade-<revision>` and is automatically deleted 5 minutes after it finishes
   (`ttlSecondsAfterFinished: 300`). Tail its logs while it runs:

   ```bash
   kubectl logs job/my-tbmq-upgrade-<revision> -n <namespace> -f
   ```

   Helm restores both StatefulSets to the chart's declared `replicas` value (default `2`) as part
   of the upgrade — no manual scale-back is needed.

### CE → PE Upgrade (Cross-Edition Migration)

Migrating an existing CE release to PE **on the same TBMQ version** is a two-edit change to your
existing `values.yaml` followed by one `helm upgrade` with the cross-edition flag. The flag sets
`FROM_VERSION=ce` on the upgrade Job (forwarded by the PE entrypoint as
`-Dinstall.upgrade.from_version=ce`), triggering the PE-specific schema and data transformations
on top of the existing CE data.

1. **Edit your existing `values.yaml`** to switch to the PE images and add a license. Both edits
   are exactly the same as for a fresh PE install — see
   [Switch to PE images](#switch-to-pe-images) and
   [Provide your license](#provide-your-license). Do not pass `values-pe.yaml` as a `-f`
   overlay alongside this file.

2. **Scale broker and IE to 0** so nothing is connected to the schema while it migrates:

   ```bash
   kubectl scale statefulset/my-tbmq-tbmq-node --replicas=0 -n <namespace>
   kubectl scale statefulset/my-tbmq-tbmq-ie   --replicas=0 -n <namespace>
   ```

3. **Run the upgrade** with the cross-edition flag:

   ```bash
   helm upgrade my-tbmq tbmq-helm-chart/tbmq-cluster \
     -n <namespace> \
     -f values.yaml \
     --set upgrade.upgradeDbSchema=true \
     --set upgrade.fromVersion=ce
   ```

What happens during this upgrade:

- The pre-upgrade Job uses the **PE** broker image (because your `values.yaml` now points at PE)
  with `UPGRADE_TB=true` and `FROM_VERSION=ce`. The PE entrypoint reads `FROM_VERSION` and
  appends `-Dinstall.upgrade.from_version=ce` to the install application command line, which
  switches the migration into CE→PE mode (rewrites the CE schema as PE).
- After the migration succeeds, Helm rolls the `tbmq-node` and `tbmq-ie` StatefulSets onto the PE
  images and restores both to the chart's declared `replicas` value — no manual scale-back is
  needed.

After the migration succeeds, **do not** carry `upgrade.fromVersion=ce` forward to subsequent
PE → PE upgrades — drop the flag (or set it to `""`) on the next `helm upgrade`. With the flag
left on, the upgrade Job repeats the CE → PE migration instead of migrating to the new TBMQ
version, and fails (see [Troubleshooting Upgrades](#troubleshooting-upgrades)).

### Troubleshooting Upgrades

The pre-upgrade migration Job spawns a Pod named `my-tbmq-upgrade-<revision>-<random>`. The Job
itself has `ttlSecondsAfterFinished: 300`, so both Job and Pod are deleted 5 minutes after the
migration finishes — successful or not. A Job that reaches `upgrade.activeDeadlineSeconds` loses
its Pods (and their logs) at once. Watch logs while the Job runs, or capture them quickly once it
terminates:

```bash
kubectl logs job/my-tbmq-upgrade-<revision> -n <namespace> -f
# or, if the Pod has already finished but hasn't been TTL-reaped yet:
kubectl logs <upgrade-pod-name> -n <namespace>
```

> The Job has `backoffLimit: 3`, and its pod template has `restartPolicy: Never` — on failure the
> Job creates a brand-new pod rather than restarting the container in place, so `kubectl logs
> --previous` doesn't apply here. List all attempts with `kubectl get pods -n <namespace> -l job-name=my-tbmq-upgrade-<revision>`.

Common causes:

- **Pod stuck in `Init:0/1` with `wait-for-postgres` repeatedly logging `waiting for postgres`** →
  PostgreSQL is unreachable. The init container echoes `waiting for postgres` between retries; an
  unresolvable host also logs `nc: bad address '<host>'`, while a refused or timed-out connection
  logs nothing else. The Job stops when `upgrade.activeDeadlineSeconds` passes (or Helm gives up
  first after `--timeout`, if you raised the limit above it). Check
  `postgresql.host`/`postgresql.port` and that the DB is reachable from the TBMQ namespace.
- **Authentication failed** → verify `postgresql.password` or that the `existingSecret` contains
  the expected key.
- **`helm upgrade` fails with `timed out waiting for the condition`** → the migration did not
  finish within `--timeout` (Helm default 5m). With the defaults the Job's deadline fires first, so
  this happens only when `upgrade.activeDeadlineSeconds` was raised above `--timeout`. The release
  is marked `failed` and the StatefulSets are not updated (they stay at 0 if you scaled down), but
  **the migration Job keeps running** in the cluster until it finishes or reaches
  `upgrade.activeDeadlineSeconds`. Follow its logs. If it succeeded, re-run the same
  `helm upgrade` **without** `upgrade.upgradeDbSchema=true`. If it failed or hit the deadline, fix
  the cause (e.g. more resources, `VACUUM`/`ANALYZE` first, a
  higher `upgrade.activeDeadlineSeconds`) and re-run with the flag and a longer `--timeout`.
- **`helm upgrade` fails with `pre-upgrade hooks failed` … `job my-tbmq-upgrade-<revision> failed`**
  → the migration Job itself failed. The release is marked `failed` and the StatefulSets are not
  updated. `BackoffLimitExceeded` means all attempts failed: read the attempts' logs (see above)
  before the Job is TTL-reaped. `DeadlineExceeded` means it reached
  `upgrade.activeDeadlineSeconds`: Kubernetes has already deleted its Pods, so
  `kubectl describe job my-tbmq-upgrade-<revision> -n <namespace>` is all that is left — most
  often the Pod never got past `wait-for-postgres` (see the first cause). Fix the cause and re-run
  the upgrade with the flag, following the logs this time.
- **`Upgrade failed: database already upgraded to current version`** → `upgrade.upgradeDbSchema=true`
  was set on an upgrade that doesn't change the TBMQ version (and isn't the CE → PE migration), so
  there is nothing to migrate. The Job exits before touching the schema. Re-run the same
  `helm upgrade` without the flag: it completes, and Helm restores the StatefulSets to their
  declared replicas.
- **CE → PE migration failed** → confirm `upgrade.fromVersion=ce` was set AND that the PE image is
  in use (check the upgrade Pod's `image:` field — it should be `thingsboard/tbmq-pe-node:<tag>`).
  `Upgrade failed: transitioning from CE to PE requires the database to first be upgraded to version
  '<version>' using TBMQ CE` means the CE database is on an older TBMQ version than the PE image:
  upgrade CE to that version first (Standard Upgrade Procedure), then migrate to PE.
- **`upgrade.fromVersion=ce` left set on a follow-up PE → PE upgrade** → the Job runs the CE → PE
  migration instead of the version migration and fails with the same `transitioning from CE to PE
  requires the database to first be upgraded …` error. Drop the flag and re-run.

### Upgrading from chart version 1.x to 2.0.0 (TBMQ 2.2.0 → 2.3.0)

Chart version 2.0.0 is a **breaking change**. All Bitnami subchart dependencies (PostgreSQL, Kafka,
Redis Cluster) that earlier chart versions bundled have been removed — the chart now expects you to
bring your own third-party infrastructure. This aligns the Helm deployment with the broader TBMQ
v2.3.0 third-party migration described in the
[official upgrade instructions](https://tbmq.io/docs/installation/upgrade-instructions/#third-party-component-updates-in-v230).

| Component        | TBMQ v2.2.0 (chart 1.x bundled)       | TBMQ v2.3.0 (chart 2.0.0 — bring your own) |
|------------------|---------------------------------------|--------------------------------------------|
| **PostgreSQL**   | `bitnami/postgresql` (PostgreSQL 16)  | `postgres:17` (operator or self-managed)   |
| **Kafka**        | `bitnamilegacy/kafka:3.7.0` (KRaft)   | `apache/kafka:4.0.0` (official image)      |
| **Redis/Valkey** | `bitnamilegacy/redis:7.2.5` (cluster) | `valkey/valkey:8.0` (Redis-compatible)     |

Chart 2.0.0 has no `postgresql:`, `kafka:`, or `redis-cluster:` subchart blocks — only top-level
`postgresql:`, `kafka:`, and `redis:` connection sections that point at your existing or newly
provisioned infrastructure.

> **Always back up your PostgreSQL database before upgrading**, regardless of which path you take.

> **Set `tbmq.persistence.enabled: false` in your chart 2.0.0 upgrade values.** Chart 2.0.0 adds a
> per-pod `volumeClaimTemplate` for `/data` on the broker StatefulSet (default
> `tbmq.persistence.enabled: true`). Chart 1.x had no such template (its `/data` was an `emptyDir`),
> and `volumeClaimTemplates` is one of the immutable fields on an existing StatefulSet — adding it
> in place makes `helm upgrade` fail with
> `StatefulSet ... is invalid: spec: Forbidden: updates to statefulset spec for fields other than ... are forbidden`.
> Chart 1.x deployments are CE-only, so disabling persistence on the upgrade is safe (there is no
> PE license cache to preserve).
>
> The pre-upgrade schema migration Job runs **before** the StatefulSet patch. If you hit this error
> on a first attempt the schema is already at the target version, and re-running the upgrade with
> `--set upgrade.upgradeDbSchema=true` will fail its already-upgraded check
> (`database already upgraded to current version`). Retry without `upgradeDbSchema` (and with
> `tbmq.persistence.enabled: false`).
>
> Enabling `tbmq.persistence` later (e.g. before a CE→PE migration on the chart 2.0.0 CE release)
> hits the same immutable-field rule. Take a maintenance window, delete the broker StatefulSet with
> `kubectl delete statefulset <release>-tbmq-node -n <namespace> --cascade=orphan` (this leaves the
> running Pod up while the StatefulSet is gone), then `helm upgrade` with
> `tbmq.persistence.enabled: true` to recreate it with the `volumeClaimTemplate`.

#### Two upgrade paths

**Option A — Keep the existing in-cluster Bitnami stack.** Annotate every Bitnami-rendered
resource in the chart 1.x release with `helm.sh/resource-policy: keep` so `helm upgrade` to chart
2.0.0 does not delete them, then point chart 2.0.0's top-level `postgresql:` / `kafka:` / `redis:`
sections at the still-running in-cluster Services and reuse the Bitnami-created Secrets. The
schema migration runs as the standard pre-upgrade Job. This path keeps PostgreSQL on major version
16 and leaves the Bitnami Pods detached from Helm — long-term, plan to migrate to the official
open-source images (Option B).

> Run `helm get manifest <release> -n <namespace>` first to see the exact list of subchart
> resources in your release and annotate based on that output — names depend on your release name
> and the exact subchart versions you originally installed. Missing a resource means
> `helm upgrade` will delete it.

**Option B — Provision a fresh third-party stack.** The cleaner long-term path: provision the
v2.3.0 reference stack (PostgreSQL 17, Apache Kafka 4.0.0, Valkey 8.0) outside the Helm release,
then run the chart 2.0.0 upgrade pointing at the new infrastructure.

PostgreSQL must carry over (`pg_dump` / `pg_restore`, or the operator equivalent) — it holds the
TBMQ schema and cluster id. For Kafka and Redis you have a choice:

- **Migrate the data.** Choose this if you need to preserve any persisted-but-undelivered MQTT
  messages and the in-cluster MQTT state held outside PostgreSQL. The image transitions
  (`bitnamilegacy/kafka:3.7.0` → `apache/kafka:4.0.0` and `bitnamilegacy/redis:7.2.5` →
  `valkey/valkey:8.0`) do not permit direct volume reuse, so plan a logical export/replay rather
  than a PV swap.
- **Start Kafka and Redis empty.** A valid choice when you accept that any
  persisted-but-undelivered messages are either already delivered or will be dropped. MQTT
  clients reconnect to the new cluster on their own and their subscriptions get re-established as
  they come back online — no operator action required for that.

The [Minikube guide](docs/minikube/README.md) walks through provisioning one such stack
end-to-end (it does not cover Kafka or Redis data migration).

For detailed assistance with either path,
[contact ThingsBoard](https://tbmq.io/contact-us/).

## Runtime Troubleshooting

Symptoms you may hit on a running cluster (separate from the install- and upgrade-time issues
covered in [Troubleshooting the Install](#troubleshooting-the-install) and
[Troubleshooting Upgrades](#troubleshooting-upgrades)).

### Broker exits immediately with `License Error GENERAL_ERROR(300)`

The broker logs:

```
ERROR o.t.m.b.d.s.BasicSubscriptionService - License secret is not provided!
ERROR o.t.m.b.d.s.BasicSubscriptionService - Please provide license.secret property value in thingsboard-mqtt-broker.yml or set TBMQ_LICENSE_SECRET environment variable!
INFO  o.t.m.b.d.s.BasicSubscriptionService - Terminating application due to critical License Error GENERAL_ERROR(300), exit code [-1]
```

PE images require a license value. Either set `license.secret` inline or pre-create a Secret and
point `license.existingSecret` at it (see [Provide your license](#provide-your-license)). The
Secret must be in the release's namespace. CE images don't need a license — confirm you didn't
pull the PE images (`thingsboard/tbmq-pe-*`) without configuring one.

### Broker crash-loops with `License Error: CLUSTER_ID_MISMATCH(114)`

The license server has bound your TBMQ license to a different cluster id than the one this
broker is presenting. The cluster id lives in PostgreSQL (`tbmq_cluster.cluster_id`, generated
once at install), so a mismatch means that row has changed since the license was activated.
Common causes:

- **PostgreSQL was wiped or recreated.** A fresh database gets a fresh `tbmq_cluster.cluster_id`
  on the next install, and the license server still holds the prior binding.
- **DB was restored from a non-matching backup.** Restoring an older or different cluster's
  backup brings back a different `tbmq_cluster.cluster_id`.
- **Same license is being activated against a different deployment.** Single-bind licenses can
  only activate against one cluster id at a time.

To recover, [contact ThingsBoard support](https://tbmq.io/contact-us/) to release the prior
binding, or restore the database that matches it.

Pod recreation, `helm upgrade`, and `/data` being an `emptyDir` do **not** trigger this error —
the cluster id is not stored under `/data`. Losing `/data` has a different cost for PE: see
[Persistence](#persistence).

## Configuration Reference

### Global Parameters

| Parameter                    | Description                                                                                                                                                                          | Default                     |
|------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| **Docker Authentication**    |                                                                                                                                                                                      |                             |
| dockerAuth.registry          | Docker registry for TBMQ images. Used only when supplying credentials.                                                                                                               | https://index.docker.io/v1/ |
| dockerAuth.username          | Docker username. When set, the chart creates a pull Secret named `tbmq.imagePullSecret` (default `regcred`). When empty, no Secret is created — useful when you pre-create your own. | ""                          |
| dockerAuth.password          | Docker password. Used together with `dockerAuth.username` to populate the chart-managed pull Secret.                                                                                 | ""                          |
| **Helper Images**            | Images used by the chart's own init containers and install/upgrade hooks. Not TBMQ images — override the repositories for a private registry or air-gapped mirror.                    |                             |
| helperImages.toolbox.repository | Image running the `validate-db` init container on the broker StatefulSet. Must provide `bash`, `psql`, and `script-runner.sh` / `psql-validator.sh` in its working directory.      | thingsboard/toolbox         |
| helperImages.toolbox.tag     | Tag for the toolbox image.                                                                                                                                                           | "1.29.0"                    |
| helperImages.busybox.repository | Image running the `wait-for-postgres` init container on the install Pod and pre-upgrade Job. Only needs a shell and `nc`.                                                          | busybox                     |
| helperImages.busybox.tag     | Tag for the busybox image.                                                                                                                                                           | "1.37.0"                    |
| **Installation**             |                                                                                                                                                                                      |                             |
| installation.installDbSchema | Initializes the TBMQ DB schema. Pass via `--set` on first install only. The post-install hook is also bound to `post-upgrade` for recovery scenarios.                                | false                       |
| installation.argocd          | Replaces Helm install/upgrade hooks with ArgoCD `Sync` hook annotations on the install pod. See [Managing the Chart with ArgoCD](#managing-the-chart-with-argocd).                   | false                       |
| installation.activeDeadlineSeconds | Hard limit on the install Pod's lifetime, including retries. The default stays below Helm's 5m `--timeout`; if you raise it, pass a longer `--timeout` too.                     | 240                         |
| **Upgrade**                  |                                                                                                                                                                                      |                             |
| upgrade.upgradeDbSchema      | Runs the DB migration during `helm upgrade` (pre-upgrade hook). Ignored on first install (except with `upgrade.argocd`, see below).                                                  | false                       |
| upgrade.argocd               | Replaces Helm pre-upgrade hooks with ArgoCD `PreSync` hook annotations on the upgrade job. See [Managing the Chart with ArgoCD](#managing-the-chart-with-argocd).                     | false                       |
| upgrade.activeDeadlineSeconds | Hard limit on the schema migration Job, including retries. The default stays below Helm's 5m `--timeout`; if you raise it, pass a longer `--timeout` too.                       | 240                         |
| upgrade.fromVersion          | Edition the upgrade is migrating FROM. Set to `"ce"` only for CE → PE cross-edition upgrades. Leave empty for same-edition upgrades.                                                 | ""                          |
| **License (PE only)**        | Required for PE; ignored for CE (when both `secret` and `existingSecret` are empty, the chart skips license wiring).                                                                 |                             |
| license.secret               | License value. When set, the chart creates a Secret `<release>-tbmq-license-secret`. Convenient for testing; the value lands in the helm release manifest.                           | ""                          |
| license.existingSecret       | Name of a pre-existing Kubernetes Secret holding the license. Recommended for production. When set, the chart does NOT create a Secret of its own.                                   | ""                          |
| license.existingSecretLicenseKey | Key inside `existingSecret` that holds the license value. Matches the convention from the official PE k8s manifests.                                                             | "license-key"               |
| license.instanceDataFile     | Path to the per-pod license cache file. Default uses `$(TB_SERVICE_ID)` (the Pod name) so each replica gets its own file under `/data`, which is PVC-backed by default (see [Persistence](#persistence)). Override only if you mount a different writable path. | "/data/tbmq-instance-license-$(TB_SERVICE_ID).data" |

### TBMQ (Broker) Parameters

| Parameter                               | Description                                                                                                                                                | Default                                 |
|-----------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| **Image**                               |                                                                                                                                                            |                                       |
| tbmq.image.repository                   | Broker image repository. CE: `thingsboard/tbmq-node`. PE: `thingsboard/tbmq-pe-node`.                                                                      | thingsboard/tbmq-node                 |
| tbmq.image.tag                          | Image tag. CE default tracks the chart `appVersion`. PE: `<appVersion>PE` (e.g. `2.4.0PE`).                                                                | 2.4.0                                 |
| tbmq.imagePullSecret                    | Pull secret name referenced by the broker StatefulSet, install Pod, and upgrade Job. Auto-created from `dockerAuth.username`/`password` if those are set; otherwise expected to exist in the namespace already. | regcred                               |
| tbmq.imagePullPolicy                    | Image pull policy.                                                                                                                                         | Always                                |
| **Scaling**                             |                                                                                                                                                            |                                       |
| tbmq.statefulSet.replicas               | Number of broker pods.                                                                                                                                     | 2                                     |
| tbmq.statefulSet.annotations            | Annotations applied to the StatefulSet resource (CI/CD, audit, etc.).                                                                                      | { }                                   |
| tbmq.annotations                        | Annotations applied to broker pods (Prometheus scrape, sidecars, etc.).                                                                                    | { }                                   |
| tbmq.nodeSelector / tbmq.affinity       | Pod scheduling rules.                                                                                                                                      | { }                                   |
| tbmq.priorityClassName                  | Optional name of an existing priority class to set on all tbmq-node pods                                                                                   | ""                                    |
| tbmq.restartPolicy                      | Pod restart policy.                                                                                                                                        | Always                                |
| **Ports**                               |                                                                                                                                                            |                                       |
| tbmq.ports                              | Container ports: HTTP 8083, MQTT 1883, MQTTS 8883, MQTT-WS 8084, MQTT-WSS 8085.                                                                            | (see values.yaml)                     |
| **Configuration**                       |                                                                                                                                                            |                                       |
| tbmq.customEnv                          | Map of env vars applied to broker pods, install Pod, and upgrade Job. Wins over keys in any `existing*ConfigMap`.                                          | { }                                   |
| tbmq.existingConfigMap                  | One ConfigMap providing both `conf` (Java opts) and `logback` (logging) keys. Highest priority — when set, the chart skips rendering its default ConfigMaps and ignores the two below. Applies to broker pods and the upgrade Job; the install Pod uses a dedicated minimal `*-install-config`. | ""                                    |
| tbmq.existingJavaOptsConfigMap          | ConfigMap with a `conf` key providing Java options. Used only when `existingConfigMap` is empty.                                                           | ""                                    |
| tbmq.existingLogbackConfigMap           | ConfigMap with a `logback` key providing logback XML. Used only when `existingConfigMap` is empty.                                                          | ""                                    |
| tbmq.enableChecksumAnnotations          | Auto-restart pods on relevant ConfigMap/Secret changes during `helm upgrade`. Logback is intentionally excluded — TBMQ hot-reloads logback every 10s.       | true                                  |
| **Health checks**                       |                                                                                                                                                            |                                       |
| tbmq.readinessProbe                     | Default: TCP 1883, initialDelay 30s, period 20s, failure threshold 5.                                                                                      | (see values.yaml)                     |
| tbmq.livenessProbe                      | Default: TCP 1883, initialDelay 60s, period 10s, failure threshold 10.                                                                                     | (see values.yaml)                     |
| **Security & resources**                |                                                                                                                                                            |                                       |
| tbmq.securityContext                    | Defaults: `runAsUser: 799`, `runAsNonRoot: true`, `fsGroup: 799`.                                                                                          | (see values.yaml)                     |
| tbmq.resources                          | CPU/memory requests and limits. Set explicitly for production.                                                                                             | { }                                   |
| **Persistence**                         |                                                                                                                                                            |                                       |
| tbmq.persistence.enabled                | Back the broker `/data` directory with a per-pod PVC (via `volumeClaimTemplate`). **Keep enabled for PE** — see [Persistence](#persistence). Safe to disable for CE. | true |
| tbmq.persistence.size                   | PVC size. The PE license cache file is a few KB; 1Gi just leaves headroom for any future PE feature that may write to `/data`. The reference PE Kubernetes manifests request 100Mi — bumping this default does not affect compatibility. | "1Gi"                                 |
| tbmq.persistence.storageClassName       | StorageClass name. Empty means use the cluster's default StorageClass.                                                                                       | ""                                    |
| tbmq.persistence.accessModes            | PVC access modes. ReadWriteOnce is correct for per-pod claims.                                                                                              | ["ReadWriteOnce"]                     |

### TBMQ Integration Executor Parameters

The `tbmq-ie` parameters mirror `tbmq` parameters above. Notable differences:

| Parameter                       | Description                                                                                                                                                | Default                               |
|---------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| tbmq-ie.image.repository        | IE image. CE: `thingsboard/tbmq-integration-executor`. PE: `thingsboard/tbmq-pe-integration-executor`.                                                     | thingsboard/tbmq-integration-executor |
| tbmq-ie.image.tag               | Image tag. CE default tracks the chart `appVersion`. PE: `<appVersion>PE` (e.g. `2.4.0PE`).                                                                | 2.4.0                                 |
| tbmq-ie.imagePullSecret         | Pull secret name referenced by the IE StatefulSet only — independent of `tbmq.imagePullSecret`. The chart auto-creates **only one** Secret (named after `tbmq.imagePullSecret`, when `dockerAuth.username` is set). If `tbmq-ie.imagePullSecret` differs, pre-create that Secret yourself. | regcred                               |
| tbmq-ie.imagePullPolicy         | Image pull policy.                                                                                                                                          | Always                                |
| tbmq-ie.statefulSet.replicas    | Number of IE pods.                                                                                                                                          | 2                                     |
| tbmq-ie.ports                   | HTTP 8082.                                                                                                                                                 |                                       |
| tbmq-ie.readinessProbe          | Default: TCP `http`, period 20s.                                                                                                                            |                                       |
| tbmq-ie.livenessProbe           | Default: TCP `http`, initialDelay 120s, period 20s.                                                                                                         |                                       |

> All other `tbmq-ie.*` keys mirror their `tbmq.*` counterparts with the same defaults and behavior:
> `statefulSet.annotations`, `annotations`, `priorityClassName`, `nodeSelector`, `affinity`, `customEnv`,
> `existingConfigMap`, `existingJavaOptsConfigMap`, `existingLogbackConfigMap`,
> `enableChecksumAnnotations`, `restartPolicy`, `securityContext`, `resources`. The IE Pod does
> **not** mount PostgreSQL, Redis, or PE license env vars — it only connects to Kafka.

> **Note:** `tbmq-ie` is referenced in templates with `index .Values "tbmq-ie"` because of the
> hyphen in the key name. The hyphen does not need escaping on the command line — use the
> dotted path directly: `--set tbmq-ie.statefulSet.replicas=3`.

### Persistence

The broker StatefulSet provisions a per-pod PVC for `/data` via `volumeClaimTemplate`.
**Professional Edition** deployments should keep this enabled (the chart default). The license
client writes a per-pod activation-response cache to
`/data/tbmq-instance-license-$(TB_SERVICE_ID).data` on first start. On subsequent starts:

- **With the cache file present**, the broker checks in with the license server using its
  existing instance id. No new slot is consumed.
- **With the cache file missing**, the broker activates again and the license server issues a
  **fresh** instance id, which counts against the license's instance cap.

The TBMQ cluster id itself lives in PostgreSQL (`tbmq_cluster.cluster_id`), not under `/data`,
so cache loss does **not** change cluster identity or trigger `CLUSTER_ID_MISMATCH`. But slots
held by instances that no longer exist are not freed automatically, so repeated activations from
sustained cache loss accumulate until they exhaust the cap. Once exhausted, new pods cannot
activate and you need to [contact ThingsBoard support](https://tbmq.io/contact-us/) to release
the stale instances. Persisting `/data` avoids the problem entirely.

For Community Edition, nothing meaningful is persisted under `/data`, so disabling
persistence is safe:

```yaml
tbmq:
  persistence:
    enabled: false
```

The Integration Executor StatefulSet and the pre-upgrade Job continue to use `emptyDir`
for `/data` — they don't carry per-instance state. The install Pod doesn't mount `/data`
at all (its only volumes are the install ConfigMap and a logs `emptyDir`).

The PVCs are named `<release>-tbmq-node-data-<release>-tbmq-node-<ordinal>` (one per broker
replica) and are **not** deleted by `helm uninstall` — see [Uninstalling](#uninstalling).

### Managing the Chart with ArgoCD

ArgoCD renders the chart with `helm template` and applies the result, so Helm hooks and
`helm --timeout` don't apply. Set `installation.argocd: true` and `upgrade.argocd: true` to switch
the install Pod and upgrade Job to ArgoCD hooks:

- **Install** — the install Pod becomes a `Sync` hook (deleted when it succeeds). Set
  `installation.installDbSchema: true` in the Application's Helm values for the **first sync
  only**, then remove it. While it is set, every sync re-runs the install Pod. A failed install
  Pod is left in place for its logs and replaced on the next sync
  (`hook-delete-policy: BeforeHookCreation,HookSucceeded`).
- **Upgrade** — the migration Job becomes a `PreSync` hook. ArgoCD can't tell an install from an
  upgrade, so the Job renders whenever `upgrade.upgradeDbSchema: true`. Set it together with the
  image tag change that bumps the TBMQ version, then remove it after that sync. The Job is always
  named `<release>-upgrade-1` (every ArgoCD render is revision 1; `<release>` is the Application
  name unless you set `spec.source.helm.releaseName`). A failed sync only reports
  `one or more synchronization tasks completed unsuccessfully`, so read the reason in the Job's
  Pod logs (`kubectl get pods -n <namespace> -l job-name=<release>-upgrade-1`). Leaving the flag
  set makes the next sync fail with `database already upgraded to current version`. **Never set it
  on the first sync:** the PreSync Job needs ConfigMaps and Secrets that the Sync phase has not
  created yet, so its Pod is stuck until `upgrade.activeDeadlineSeconds` runs out. With the
  chart's default ConfigMaps it sits in `Init:0/1` with `FailedMount … configmap … not found`
  events in `kubectl describe pod` (not a PostgreSQL problem, despite the same `Init:0/1` status).
  With `existingConfigMap` (or both `existingJavaOptsConfigMap` and `existingLogbackConfigMap`)
  the volumes mount, and the main container fails with `CreateContainerConfigError` on the
  missing `*-postgres-config` / `*-tbmq-custom-env` / chart-managed Secrets instead. To scale down
  before the migration as in the [Standard Upgrade Procedure](#standard-upgrade-procedure),
  disable auto-sync self-heal first so ArgoCD doesn't scale the StatefulSets back up.
- **Timeouts** — the hooks are bounded only by `installation.activeDeadlineSeconds` and
  `upgrade.activeDeadlineSeconds`.

## Load Balancer

The chart creates Kubernetes `Ingress` (for HTTP) and `Service` (for MQTT) resources. It does
**not** deploy the load balancer or ingress controller itself — those must already exist in your
cluster (NGINX Ingress Controller, AWS Load Balancer Controller, Application Gateway Ingress
Controller, etc.).

| Parameter                                               | Description                                                                                              | Default                |
|---------------------------------------------------------|----------------------------------------------------------------------------------------------------------|------------------------|
| loadbalancer.type                                       | Provider flavor: `"nginx"`, `"aws"`, `"azure"`, `"gcp"`. Selects template variant + default annotations. | "nginx"                |
| loadbalancer.http.enabled                               | Create the HTTP Ingress.                                                                                 | true                   |
| loadbalancer.http.annotations                           | Extra Ingress annotations. Merged with provider defaults — user values win on conflict.                  | { }                    |
| loadbalancer.http.ssl.enabled                           | Enable HTTPS termination at the load balancer. Honored by `aws`, `azure`, and `gcp` flavors; the `nginx` template does not implement HTTPS termination and ignores this key. | false                  |
| loadbalancer.http.ssl.certificateRef                    | Cert reference: AWS ACM ARN, Azure `appgw-ssl-certificate` value, GCP `ManagedCertificate` name.        | ""                     |
| loadbalancer.http.ssl.domains                           | Domains for HTTPS. Required for GCP `ManagedCertificate`.                                                | ["www.example.com"]    |
| loadbalancer.http.ssl.staticIP                          | GCP-only: static IP name for the HTTP(S) load balancer.                                                  | "tbmq-http-lb-address" |
| loadbalancer.mqtt.enabled                               | Create the MQTT LoadBalancer Service.                                                                    | true                   |
| loadbalancer.mqtt.annotations                           | Extra Service annotations. Merged with provider defaults — user values win on conflict.                  | { }                    |
| loadbalancer.mqtt.mutualTls.enabled                     | Enable application-level mTLS. Requires server cert + key. Disables `tlsTermination`.                    | false                  |
| loadbalancer.mqtt.mutualTls.configMapName               | ConfigMap with `server.pem` and `mqttserver_key.pem` keys.                                               | "tbmq-node-mqtts-config" |
| loadbalancer.mqtt.mutualTls.existingSecretName          | Optional secret with `server.pem` and `mqttserver_key.pem` keys, replaces `.configMapName`.              | "" |
| loadbalancer.mqtt.mutualTls.privateKeyPasswordSecret    | Optional Secret holding the private key password.                                                        | ""                     |
| loadbalancer.mqtt.mutualTls.privateKeyPasswordSecretKey | Key inside the Secret with the private key password.                                                     | "key_password"         |
| loadbalancer.mqtt.tlsTermination.enabled                | Enable L4 TLS termination at the load balancer. Supported on AWS NLB only. Ignored if mTLS is enabled.   | false                  |
| loadbalancer.mqtt.tlsTermination.certificateRef         | AWS NLB ACM certificate ARN.                                                                             | ""                     |

## Mutual TLS (mTLS) for MQTT

To enable application-level mTLS for the MQTT listener:

1. Create a Secret holding the server certificate and private key (recommended, since it holds a
   private key). It must use the keys `server.pem` and `mqttserver_key.pem`:

   ```bash
   kubectl create secret generic tbmq-node-mqtts-config -n <namespace> \
     --from-file=server.pem=/path/to/server.pem \
     --from-file=mqttserver_key.pem=/path/to/mqttserver_key.pem \
     -o yaml --dry-run=client | kubectl apply -f -
   ```

   Alternatively, use a ConfigMap with the same keys and reference it via `configMapName` in
   step 3:

   ```bash
   kubectl create configmap tbmq-node-mqtts-config -n <namespace> \
     --from-file=server.pem=/path/to/server.pem \
     --from-file=mqttserver_key.pem=/path/to/mqttserver_key.pem \
     -o yaml --dry-run=client | kubectl apply -f -
   ```

2. (Optional) If the private key is password-protected, create a Secret:

   ```bash
   kubectl create secret generic mqtt-tls-secret -n <namespace> \
     --from-literal=key_password="YOUR_KEY_PASSWORD" \
     -o yaml --dry-run=client | kubectl apply -f -
   ```

3. Enable mTLS in your `values.yaml`:

   ```yaml
   loadbalancer:
     mqtt:
       enabled: true
       mutualTls:
         enabled: true
         existingSecretName: "tbmq-node-mqtts-config"
         # configMapName: "tbmq-node-mqtts-config"      # if you used a ConfigMap instead; existingSecretName takes precedence when set
         privateKeyPasswordSecret: "mqtt-tls-secret"      # omit if not needed
         privateKeyPasswordSecretKey: "key_password"      # omit if not needed
   ```

## Uninstalling

```bash
helm uninstall my-tbmq -n <namespace>
```

`helm uninstall` removes the Kubernetes resources owned by the release (StatefulSets, Services,
ConfigMaps, chart-managed Secrets, Ingress, and the load balancer Service). It does **not** touch:

- **External infrastructure** — PostgreSQL data, Kafka topics, and Redis cache are owned by the
  systems you deployed alongside TBMQ. Drop them explicitly if you no longer need them.
- **Pre-existing Secrets** — anything referenced via `postgresql.existingSecret`,
  `redis.existingSecret`, `license.existingSecret`, or a pre-created `tbmq.imagePullSecret` is
  left in place.
- **Per-pod PVCs created from `volumeClaimTemplate`** — the broker's `tbmq-node-data` PVCs are kept
  by design (StatefulSet semantics). Delete them by name pattern:

  ```bash
  kubectl get pvc -n <namespace> -o name | grep tbmq-node-data \
    | xargs -r kubectl delete -n <namespace>
  ```

  Or delete the whole namespace if you no longer need anything in it.
